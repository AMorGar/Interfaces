Nombre de variables:

errorText: Mensaje de error. 
labelText: campo situado a la derecha.
errorImagenFile: Introducir imagen de error.
hint: placehonder (como en html).
successImageFile: Introducir imagen de correcto.


Profe apruébame porfa, está bien fachero. :)